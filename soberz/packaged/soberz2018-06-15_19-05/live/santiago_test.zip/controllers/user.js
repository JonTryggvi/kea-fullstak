const bcrypt = require('bcrypt-nodejs')

const user = {}

user.login = function (req, res) {
  
}