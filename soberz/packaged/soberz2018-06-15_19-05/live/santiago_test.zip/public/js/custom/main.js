
let drawer = new mdc.drawer.MDCPersistentDrawer(document.querySelector('.mdc-drawer--persistent'));
let btnMenu = document.querySelector('.menu');
btnMenu.addEventListener('click', () => { let drawerState = drawer.open ? drawer.open : !drawer.open; return drawerState; });


$(document).ready(function () {
  $.get('/get-users', function (data) {


    console.log(data);
    
  });
});