window.onload = function () {
  $('.loader').addClass('hideLoader');
};

var socket = io('localhost:3000');
var userId = localStorage.userId;
var navChat = $('#ancChat').attr('href');
let navAddId = navChat + '/' + userId;
var navUsers = $('#ancUsers').attr('href');
let navAddUsersId = navUsers + '/' + userId;
$('#ancChat').attr('href', navAddId);
$('#ancUsers').attr('href', navAddUsersId);

$('form').on('keyup', function (e) {
  var keyCode = e.keyCode || e.which;
  if (keyCode === 13) {
    
    e.preventDefault();
    $('form button').click();
    return false;
  }
});
// just to be sure that forms wont do anything unwanted I added the keaypress listener
$('form').on('keypress', function (e) {
  var keyCode = e.keyCode || e.which;
  if (keyCode === 13) {
    e.preventDefault();
    // $('form button').click();
    return false;
  }
});

$(document).ready(function () {
  $('.sidenav').sidenav();
});