const bcrypt = require('bcrypt-nodejs')

function isJson(str) {
  try {
    JSON.parse(str);
  } catch (e) {
    return false;
  }
  return true;
}

const jUser = {}

jUser.login = function (req, res) {
  const password = req.body.password 
  const email = req.body.email
  const stmt = "SELECT Users.id, Users.firstname, Users.lastname, Users.activated, Users.online, user_roles.role_name FROM Users INNER JOIN user_roles ON Users.user_role = user_roles.role_id  WHERE (email = $auth OR mobile = $auth) AND password = $pass"
  const params = {
    $auth: email,
    $pass: password
  }
  gDb.get(stmt, params, function (err, jRow) {
    if (err) {
      const jError = { message: 'update User login error: ' + err, where: 'update online status -> loginUser function: 1' }
      gLog('err', jError.message + ' -> ' + jError.where)
      const sjError = JSON.stringify(jError)
      return res.json(sjError)
    }
    gDb.run('UPDATE Users SET online = ? WHERE Users.id = ?', [1, jRow.id], function (err) {
      if (err) {
        jError = { message: 'update User set online error: ' + err, where: 'update online status -> loginUser function: 2' }
        gLog('err', jError.message + ' -> ' + jError.where)
        return false
      }
    })
    
    const jRes = { message: 'ok', response: jRow }
    return res.json(jRes)
  })
  // gDb.close() 
}

jUser.getThisUser = function (req, res) {
  const userId = req.body.userId
  const stmt = "SELECT about, json_extract(a.imgUrl, '$') AS userImg, json_extract(a.sponsors, '$') AS sponsors, json_extract(a.sponsees, '$') AS sponsees, a.id, a.email, a.firstname, a.lastname, a.mobile, a.sponsor, a.username, a.online, a.activated, b.gender_name AS gender, c.role_name AS role FROM Users AS a INNER JOIN genders  AS b ON (a.gender = b.id) INNER JOIN user_roles AS c ON (a.user_role = c.role_id) WHERE a.activated = 1 AND a.id = ?"
  gDb.all(stmt, [userId], function (err, jRow) {
    if (err) {
      const jError = { success: 'failed', message: 'Get logged in User error: ' + err, where: 'controllers/user.js -> getThisUser function' }
      gLog('err', jError.message + ' -> ' + jError.where)
      const sjError = JSON.stringify(jError)
      return res.json(sjError)
    }
    const jRes = { success:'ok', message: 'ok', response: jRow[0] }
    return res.json(jRes)
  })
}

jUser.getGenders = function (req, res) {
  const stmt = "SELECT * FROM genders"
  gDb.all(stmt, function (err, jRow) {
    if (err) {
      const jError = {success: 'ok', message: 'Get gendeer in User error: ' + err, where: 'controllers/user.js -> getGender function' }
      gLog('err', jError.message + ' -> ' + jError.where)
      return res.json(jError)
    }
    const jRes = { success: 'ok', message: 'ok', response: jRow }
    return res.json(jRes)
  })
}

jUser.updateUserbyField = function (req, res) {
  try {
    // console.log(req.fields);
    const columnName = req.body.name
    let dataValue = req.body.value
    const userId = req.body.userId
    const stmt = 'UPDATE Users SET ' + columnName + ' = ? WHERE Users.id = ?';
    const params = [dataValue, userId]
    // console.log(columnName);

    gDb.run(stmt, params, function (err) {
      if (err) {
        const jError = { status: 'failed', message: 'updateUserbyField query failed ' + err }
        return res.json(jError)
      }
      let dataValueChecked;
      if (isJson(dataValue)) {
        dataValueChecked = JSON.parse(dataValue);
      } else {
        dataValueChecked = dataValue
      }
      const jSuccess = { status: 'ok', message: 'Userfield: ' + columnName + ' has been updateed', updatedData: { name: columnName, userId: userId, value: dataValueChecked } }
      return res.json(jSuccess)
     
    })
  } catch (error) {
    const err = { message: error.message, where: 'controllers/users.js -> updateUserByField function' }
    gLog('err', err.message + ' -> ' + err.where)
    return res.json(err)
    
  }
}

jUser.getUsers = function (req, res, fCallback) {
  const query = `SELECT about, json_extract(a.imgUrl, '$') AS userImg, json_extract(a.sponsors, '$') AS sponsors, json_extract(a.sponsees, '$') AS sponsees, a.id, a.email, a.firstname, a.lastname, a.mobile, a.sponsor, a.username, a.online, a.activated, b.gender_name AS gender, c.role_name AS role FROM Users AS a INNER JOIN genders  AS b ON (a.gender = b.id) INNER JOIN user_roles AS c ON (a.user_role = c.role_id) WHERE a.activated = 1`
  gDb.all(query, function (err, jData) {
    if (err) {
      const jError = { message: err.message, where: 'get-users' }
      gLog('err', `${jError.message} -> in ${jError.where}`)
      return fCallback(true, jError)
    }
    return fCallback(false, jData)
    
  })
}

module.exports = jUser